package ObjectsAndLogic;

public class Wallet {

    public static void recharge(Customer c ,double money){


    }

    public static void recharge(Assistant c ,double money){


    }

    public static void spend(Customer c ,double money){


    }

    public static void spend(Assistant c ,double money){


    }
}
